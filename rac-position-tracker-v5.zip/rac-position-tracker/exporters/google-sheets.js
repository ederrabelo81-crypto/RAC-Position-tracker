/**
 * ══════════════════════════════════════════════════════════════
 * EXPORTADOR — Google Sheets API v4
 * ══════════════════════════════════════════════════════════════
 * Autenticação via Service Account (credentials.json)
 * 
 * Setup:
 * 1. Criar projeto no Google Cloud Console
 * 2. Ativar Google Sheets API
 * 3. Criar Service Account e baixar JSON de credenciais
 * 4. Compartilhar a planilha com o email do Service Account
 * 5. Salvar o JSON como ./credentials.json
 */

const { google } = require('googleapis');
const fs = require('fs');
const path = require('path');
const { log, logError, logSuccess } = require('../utils/logger');

/**
 * Autentica com Google usando Service Account
 */
async function getAuthClient(credentialsPath) {
  const fullPath = path.resolve(credentialsPath);
  if (!fs.existsSync(fullPath)) {
    throw new Error(
      `Arquivo de credenciais não encontrado: ${fullPath}\n` +
      'Siga as instruções no README para configurar a autenticação.'
    );
  }

  const credentials = JSON.parse(fs.readFileSync(fullPath, 'utf8'));
  const auth = new google.auth.GoogleAuth({
    credentials,
    scopes: ['https://www.googleapis.com/auth/spreadsheets'],
  });
  return auth.getClient();
}

/**
 * Mapeia os resultados para linhas da planilha
 */
function resultsToRows(results) {
  return results.map(r => [
    r.data,
    r.turno,
    r.horario,
    r.analista,
    r.plataforma,
    r.tipoPlataforma,
    r.keyword,
    r.categoriaKeyword,
    r.marca,
    r.produto,
    r.posicaoOrganica ?? '',
    r.posicaoPatrocinada ?? '',
    r.posicaoGeral ?? '',
    r.preco ? r.preco.toFixed(2).replace('.', ',') : '',
    r.seller,
    r.fulfillment,
    r.avaliacao ?? '',
    r.qtdAvaliacoes ?? '',
    r.tagDestaque,
    '', // Variação (calculada na planilha)
    r.observacoes,
    '', // Print/Evidência
  ]);
}

/**
 * Escreve os resultados no Google Sheets
 */
async function writeToGoogleSheets(results, config) {
  if (!config.enabled) {
    log('Google Sheets desabilitado na configuração');
    return;
  }

  if (config.spreadsheetId === 'SEU_SPREADSHEET_ID_AQUI') {
    throw new Error(
      'Configure o spreadsheetId no config.js com o ID da sua planilha Google.\n' +
      'O ID é a parte da URL entre /d/ e /edit'
    );
  }

  log('Conectando ao Google Sheets...');
  const authClient = await getAuthClient(config.credentialsPath);
  const sheets = google.sheets({ version: 'v4', auth: authClient });

  const rows = resultsToRows(results);

  // Verificar se o header já existe
  try {
    const headerCheck = await sheets.spreadsheets.values.get({
      spreadsheetId: config.spreadsheetId,
      range: `'${config.sheetName}'!A1:V1`,
    });

    if (!headerCheck.data.values || headerCheck.data.values.length === 0) {
      // Inserir headers
      const headers = [
        'Data', 'Turno', 'Horário', 'Analista', 'Plataforma', 'Tipo Plataforma',
        'Keyword Buscada', 'Categoria Keyword', 'Marca Monitorada', 'Produto / SKU',
        'Posição Orgânica', 'Posição Patrocinada', 'Posição Geral',
        'Preço (R$)', 'Seller', 'Fulfillment?',
        'Avaliação', 'Qtd Avaliações', 'Tag Destaque',
        'Variação', 'Observações', 'Print / Evidência',
      ];
      await sheets.spreadsheets.values.update({
        spreadsheetId: config.spreadsheetId,
        range: `'${config.sheetName}'!A1:V1`,
        valueInputOption: 'USER_ENTERED',
        requestBody: { values: [headers] },
      });
      log('Headers inseridos na planilha');
    }
  } catch (err) {
    logError(`Erro ao verificar headers: ${err.message}`);
  }

  // Append dos dados (adiciona após a última linha preenchida)
  try {
    const response = await sheets.spreadsheets.values.append({
      spreadsheetId: config.spreadsheetId,
      range: `'${config.sheetName}'!A:V`,
      valueInputOption: 'USER_ENTERED',
      insertDataOption: 'INSERT_ROWS',
      requestBody: { values: rows },
    });

    const updatedRange = response.data.updates.updatedRange;
    const updatedRows = response.data.updates.updatedRows;
    logSuccess(`  ${updatedRows} linhas adicionadas em ${updatedRange}`);

  } catch (err) {
    logError(`Erro ao escrever dados: ${err.message}`);
    throw err;
  }
}

module.exports = { writeToGoogleSheets };
