/**
 * ══════════════════════════════════════════════════════════════
 * EXPORTADOR — Excel Local (ExcelJS)
 * ══════════════════════════════════════════════════════════════
 * Gera/atualiza arquivo .xlsx local com formatação profissional.
 */

const ExcelJS = require('exceljs');
const fs = require('fs');
const path = require('path');
const { log, logSuccess } = require('../utils/logger');

const HEADER_FILL = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF003366' } };
const HEADER_FONT = { name: 'Arial', bold: true, color: { argb: 'FFFFFFFF' }, size: 11 };
const INPUT_FONT = { name: 'Arial', color: { argb: 'FF0000FF' }, size: 10 };
const BODY_FONT = { name: 'Arial', size: 10 };
const ALT_FILL = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF2F2F2' } };
const THIN_BORDER = {
  top: { style: 'thin', color: { argb: 'FFB4B4B4' } },
  bottom: { style: 'thin', color: { argb: 'FFB4B4B4' } },
  left: { style: 'thin', color: { argb: 'FFB4B4B4' } },
  right: { style: 'thin', color: { argb: 'FFB4B4B4' } },
};

const HEADERS = [
  'Data', 'Turno', 'Horário', 'Analista', 'Plataforma', 'Tipo Plataforma',
  'Keyword Buscada', 'Categoria Keyword', 'Marca Monitorada', 'Produto / SKU',
  'Posição Orgânica', 'Posição Patrocinada', 'Posição Geral',
  'Preço (R$)', 'Seller / Vendedor', 'Fulfillment?',
  'Avaliação', 'Qtd Avaliações', 'Tag Destaque',
  'Variação', 'Observações', 'Print / Evidência',
];

const COL_WIDTHS = [12, 12, 10, 14, 22, 16, 30, 20, 16, 35, 14, 14, 14, 16, 22, 12, 10, 12, 16, 12, 35, 20];

/**
 * Gera o caminho do arquivo baseado na data e padrão
 */
function getFilePath(config) {
  const today = new Date();
  const monthStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}`;
  const dateStr = today.toISOString().split('T')[0];

  if (!fs.existsSync(config.outputDir)) {
    fs.mkdirSync(config.outputDir, { recursive: true });
  }

  if (config.appendMode) {
    // Modo append: um arquivo por mês
    return path.join(config.outputDir, `posicionamento_${monthStr}.xlsx`);
  }
  // Modo individual: um arquivo por dia
  return path.join(config.outputDir, config.fileNamePattern.replace('{date}', dateStr));
}

/**
 * Escreve resultados em arquivo Excel local
 */
async function writeToExcel(results, config) {
  if (!config.enabled) {
    log('Excel local desabilitado na configuração');
    return null;
  }

  const filePath = getFilePath(config);
  let workbook;
  let ws;
  let startRow;

  if (config.appendMode && fs.existsSync(filePath)) {
    // Abrir arquivo existente e adicionar dados
    log(`  Abrindo arquivo existente: ${path.basename(filePath)}`);
    workbook = new ExcelJS.Workbook();
    await workbook.xlsx.readFile(filePath);
    ws = workbook.getWorksheet('Registro Diário') || workbook.worksheets[0];
    startRow = ws.rowCount + 1;
  } else {
    // Criar novo workbook
    log(`  Criando novo arquivo: ${path.basename(filePath)}`);
    workbook = new ExcelJS.Workbook();
    workbook.creator = 'RAC Position Tracker';
    workbook.created = new Date();

    ws = workbook.addWorksheet('Registro Diário', {
      properties: { tabColor: { argb: 'FF003366' } },
      views: [{ state: 'frozen', ySplit: 1 }],
    });

    // Headers
    const headerRow = ws.addRow(HEADERS);
    headerRow.height = 35;
    headerRow.eachCell((cell, colNumber) => {
      cell.fill = HEADER_FILL;
      cell.font = HEADER_FONT;
      cell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
      cell.border = THIN_BORDER;
    });

    // Column widths
    COL_WIDTHS.forEach((w, i) => {
      ws.getColumn(i + 1).width = w;
    });

    // AutoFilter
    ws.autoFilter = { from: 'A1', to: 'V1' };
    startRow = 2;
  }

  // Adicionar dados
  results.forEach((r, idx) => {
    const row = ws.addRow([
      r.data,
      r.turno,
      r.horario,
      r.analista,
      r.plataforma,
      r.tipoPlataforma,
      r.keyword,
      r.categoriaKeyword,
      r.marca,
      r.produto,
      r.posicaoOrganica ?? '',
      r.posicaoPatrocinada ?? '',
      r.posicaoGeral ?? '',
      r.preco ?? '',
      r.seller,
      r.fulfillment,
      r.avaliacao ?? '',
      r.qtdAvaliacoes ?? '',
      r.tagDestaque,
      '', // Variação — manual ou via fórmula
      r.observacoes,
      '',
    ]);

    const rowNum = startRow + idx;
    row.eachCell((cell, colNumber) => {
      cell.font = BODY_FONT;
      cell.border = THIN_BORDER;
      cell.alignment = { vertical: 'middle', wrapText: true };

      // Alternate row coloring
      if (rowNum % 2 === 0) {
        cell.fill = ALT_FILL;
      }
    });

    // Formatos específicos
    if (r.preco) {
      row.getCell(14).numFmt = '#,##0.00';
    }
    if (r.avaliacao) {
      row.getCell(17).numFmt = '0.0';
    }
  });

  await workbook.xlsx.writeFile(filePath);
  logSuccess(`  ${results.length} registros salvos em ${path.basename(filePath)}`);
  return filePath;
}

module.exports = { writeToExcel };
