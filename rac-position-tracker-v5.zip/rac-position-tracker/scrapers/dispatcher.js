/**
 * ══════════════════════════════════════════════════════════════
 * SCRAPER DISPATCHER v5 — Todas as plataformas
 * ══════════════════════════════════════════════════════════════
 *
 * ✅ Mercado Livre  — evaluate() + popup handling
 * ✅ Amazon Brasil  — evaluate() + domcontentloaded
 * ✅ Magazine Luiza — evaluate() + data-testid selectors
 * ⚡ Casas Bahia   — URL corrigida + stealth evasions
 * ⚡ Shopee        — cookies de login + evaluate()
 * ⚡ Google Shop.  — stealth evasions (pode falhar com captcha)
 *
 * Técnicas anti-detecção aplicadas no index.js:
 *   - webdriver flag removido
 *   - navigator.plugins simulado
 *   - chrome.runtime simulado
 *   - permissions.query interceptado
 */

const { log, logError, logWarn } = require('../utils/logger');
const { loadCookies, hasCookies } = require('../salvar-cookies');

// ═══════════════════════════════════════════════
// UTILITÁRIOS
// ═══════════════════════════════════════════════

function detectBrand(productName, brands) {
  if (!productName) return 'Desconhecida';
  const lower = productName.toLowerCase();
  const sorted = [...brands].sort((a, b) => b.length - a.length);
  for (const brand of sorted) {
    if (lower.includes(brand.toLowerCase())) return brand;
  }
  return 'Outra';
}

function buildSearchUrl(platformId, keyword) {
  const term = keyword.term;
  switch (platformId) {
    case 'meli':
      return `https://lista.mercadolivre.com.br/${term.replace(/\s+/g, '-')}`;
    case 'amazon':
      return `https://www.amazon.com.br/s?k=${encodeURIComponent(term)}`;
    case 'magalu':
      return `https://www.magazineluiza.com.br/busca/${encodeURIComponent(term)}/`;
    case 'casasbahia':
      // URL CORRIGIDA: usar /busca/ não /{keyword}/b
      return `https://www.casasbahia.com.br/busca/${encodeURIComponent(term)}`;
    case 'shopee':
      return `https://shopee.com.br/search?keyword=${encodeURIComponent(term)}`;
    case 'google_shopping':
      return `https://www.google.com.br/search?q=${encodeURIComponent(term)}&tbm=shop&hl=pt-BR`;
    default:
      return '';
  }
}

async function aggressiveScroll(page) {
  await page.evaluate(async () => {
    for (let i = 0; i < 10; i++) {
      window.scrollBy(0, 600);
      await new Promise(r => setTimeout(r, 400));
    }
    window.scrollTo(0, 0);
  });
  await page.waitForTimeout(2000);
}

/**
 * Aplica evasões stealth no contexto do page (chamar antes de navegar)
 */
async function applyStealthScripts(page) {
  await page.addInitScript(() => {
    // Remover webdriver flag
    Object.defineProperty(navigator, 'webdriver', { get: () => false });

    // Simular plugins
    Object.defineProperty(navigator, 'plugins', {
      get: () => [
        { name: 'Chrome PDF Plugin', filename: 'internal-pdf-viewer' },
        { name: 'Chrome PDF Viewer', filename: 'mhjfbmdgcfjbbpaeojofohoefgiehjai' },
        { name: 'Native Client', filename: 'internal-nacl-plugin' },
      ],
    });

    // Simular languages
    Object.defineProperty(navigator, 'languages', { get: () => ['pt-BR', 'pt', 'en-US', 'en'] });

    // Simular chrome.runtime
    window.chrome = { runtime: {}, loadTimes: () => {}, csi: () => {} };

    // Interceptar permissions.query para não revelar "denied"
    const origQuery = window.navigator.permissions?.query?.bind(window.navigator.permissions);
    if (origQuery) {
      window.navigator.permissions.query = (params) => {
        if (params.name === 'notifications') {
          return Promise.resolve({ state: Notification.permission });
        }
        return origQuery(params);
      };
    }
  });
}

// ═══════════════════════════════════════════════
// MERCADO LIVRE
// ═══════════════════════════════════════════════

async function scrapeMeli(page, keyword, brands) {
  const url = buildSearchUrl('meli', keyword);

  await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 45000 });
  await page.waitForTimeout(5000);

  // Fechar popups
  try { const b = await page.$('text=Entendi'); if (b) { await b.click(); await page.waitForTimeout(500); } } catch (_) {}
  try { const b = await page.$('button:has-text("Aceitar cookies")'); if (b) { await b.click(); } } catch (_) {}

  await aggressiveScroll(page);

  const rawResults = await page.evaluate(() => {
    const items = document.querySelectorAll('li.ui-search-layout__item');
    const data = [];
    items.forEach((item, index) => {
      if (index >= 20) return;
      try {
        let title = '';
        const titleEl = item.querySelector('.poly-component__title');
        if (titleEl) title = titleEl.textContent.trim();
        if (!title) { const h2 = item.querySelector('h2'); if (h2) title = h2.textContent.trim(); }
        if (!title || title.length < 5) return;

        let price = null;
        const pc = item.querySelector('.poly-price__current');
        if (pc) { const f = pc.querySelector('.andes-money-amount__fraction'); if (f) { price = parseFloat(f.textContent.trim().replace(/\./g, '')) || null; } }
        if (!price) { const f = item.querySelector('.andes-money-amount__fraction'); if (f) { price = parseFloat(f.textContent.trim().replace(/\./g, '')) || null; } }

        const sellerEl = item.querySelector('.poly-component__seller');
        const seller = sellerEl ? sellerEl.textContent.trim() : '';
        const hlEl = item.querySelector('.poly-component__highlight');
        const highlight = hlEl ? hlEl.textContent.trim() : '';
        let rating = null;
        const phrEl = item.querySelector('.poly-phrase-label');
        if (phrEl) { const m = phrEl.textContent.match(/[\d,.]+/); if (m) rating = parseFloat(m[0].replace(',', '.')); }
        const isSponsored = !!item.querySelector('.poly-component__ads-label');
        const hasFull = !!(item.querySelector('.poly-component__shipped-full') || item.querySelector('svg[class*="full"]'));

        data.push({ title, price, seller, highlight, rating, isSponsored, hasFull, position: index + 1 });
      } catch (_) {}
    });
    return data;
  });

  log(`    Extraidos ${rawResults.length} produtos via evaluate()`);
  return rawResults.map(r => ({
    brand: detectBrand(r.title, brands), productName: r.title.substring(0, 150),
    organicPosition: r.isSponsored ? null : r.position, sponsoredPosition: r.isSponsored ? r.position : null,
    generalPosition: r.position, price: r.price, seller: (r.seller || '').substring(0, 60),
    fulfillment: r.hasFull ? 'Sim' : 'Nao', rating: r.rating, reviewCount: null,
    tag: r.highlight || (r.isSponsored ? 'Patrocinado' : 'Nenhum'), notes: r.isSponsored ? 'Anuncio patrocinado' : '',
  }));
}

// ═══════════════════════════════════════════════
// AMAZON BRASIL
// ═══════════════════════════════════════════════

async function scrapeAmazon(page, keyword, brands) {
  const url = buildSearchUrl('amazon', keyword);
  await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 30000 });
  try { await page.waitForSelector('div[data-component-type="s-search-result"]', { timeout: 15000 }); } catch (_) {
    logWarn(`    Resultados nao carregaram em Amazon para "${keyword.term}"`); return [];
  }
  await page.waitForTimeout(3000);
  try { const b = await page.$('#sp-cc-accept'); if (b) await b.click(); } catch (_) {}
  await aggressiveScroll(page);

  const rawResults = await page.evaluate(() => {
    const items = document.querySelectorAll('div[data-component-type="s-search-result"]');
    const data = [];
    items.forEach((item, index) => {
      if (index >= 20) return;
      try {
        const asin = item.getAttribute('data-asin'); if (!asin) return;
        const h2 = item.querySelector('h2'); let title = h2 ? h2.textContent.trim() : '';
        if (!title || title.length < 5) return;
        let price = null;
        const off = item.querySelector('.a-price .a-offscreen');
        if (off) { price = parseFloat(off.textContent.replace(/[R$\s\u00a0]/g, '').replace(/\./g, '').replace(',', '.')) || null; }
        let rating = null;
        const rEl = item.querySelector('.a-icon-alt');
        if (rEl) { const m = rEl.textContent.match(/[\d,]+/); if (m) rating = parseFloat(m[0].replace(',', '.')); }
        let reviewCount = null;
        const revEl = item.querySelector('span.a-size-base.s-underline-text');
        if (revEl) { const m = revEl.textContent.match(/[\d.]+/); if (m) reviewCount = parseInt(m[0].replace('.', ''), 10); }
        const isSponsored = !!item.querySelector('.puis-label-popover-default, .s-label-popover-default');
        const badge = item.querySelector('.a-badge-text');
        const badgeText = badge ? badge.textContent.trim() : '';
        data.push({ title, price, rating, reviewCount, isSponsored, badge: badgeText, position: index + 1 });
      } catch (_) {}
    });
    return data;
  });

  log(`    Extraidos ${rawResults.length} produtos via evaluate()`);
  return rawResults.map(r => ({
    brand: detectBrand(r.title, brands), productName: r.title.substring(0, 150),
    organicPosition: r.isSponsored ? null : r.position, sponsoredPosition: r.isSponsored ? r.position : null,
    generalPosition: r.position, price: r.price, seller: '', fulfillment: 'Nao',
    rating: r.rating, reviewCount: r.reviewCount,
    tag: r.badge || (r.isSponsored ? 'Patrocinado' : 'Nenhum'), notes: r.isSponsored ? 'Anuncio patrocinado' : '',
  }));
}

// ═══════════════════════════════════════════════
// MAGAZINE LUIZA
// ═══════════════════════════════════════════════

async function scrapeMagalu(page, keyword, brands) {
  const url = buildSearchUrl('magalu', keyword);
  await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 45000 });
  try { await page.waitForSelector('a[data-testid="product-card-container"]', { timeout: 15000 }); } catch (_) {
    logWarn(`    Resultados nao carregaram em Magalu para "${keyword.term}"`); return [];
  }
  await page.waitForTimeout(3000);
  await aggressiveScroll(page);

  const rawResults = await page.evaluate(() => {
    const items = document.querySelectorAll('a[data-testid="product-card-container"]');
    const data = [];
    items.forEach((item, index) => {
      if (index >= 20) return;
      try {
        const titleEl = item.querySelector('[data-testid="product-title"]');
        const title = titleEl ? titleEl.textContent.trim() : ''; if (!title || title.length < 5) return;
        let price = null;
        const priceEl = item.querySelector('[data-testid="price-value"]');
        if (priceEl) { const m = priceEl.textContent.match(/[\d.]+,\d{2}/); if (m) price = parseFloat(m[0].replace(/\./g, '').replace(',', '.')) || null; }
        const dataBrand = item.getAttribute('data-brand') || '';
        const href = item.getAttribute('href') || '';
        const isSponsored = href.includes('ads=patrocinado');
        const sellerMatch = href.match(/seller_id=([^&"]+)/);
        const seller = sellerMatch ? sellerMatch[1] : '';
        const shipEl = item.querySelector('[data-testid="productCard-shipping-tag"]');
        const shipping = shipEl ? shipEl.textContent.trim() : '';
        data.push({ title, price, dataBrand, seller, isSponsored, shipping, position: index + 1 });
      } catch (_) {}
    });
    return data;
  });

  log(`    Extraidos ${rawResults.length} produtos via evaluate()`);
  return rawResults.map(r => {
    let brand = r.dataBrand ? r.dataBrand.replace(/-/g, ' ').replace(/\b\w/g, c => c.toUpperCase()) : detectBrand(r.title, brands);
    if (brand.toLowerCase().includes('midea')) brand = 'Midea';
    return {
      brand, productName: r.title.substring(0, 150),
      organicPosition: r.isSponsored ? null : r.position, sponsoredPosition: r.isSponsored ? r.position : null,
      generalPosition: r.position, price: r.price, seller: (r.seller || '').substring(0, 60),
      fulfillment: r.shipping ? 'Sim' : 'Nao', rating: null, reviewCount: null,
      tag: r.isSponsored ? 'Patrocinado' : (r.shipping || 'Nenhum'), notes: r.isSponsored ? 'Anuncio patrocinado' : '',
    };
  });
}

// ═══════════════════════════════════════════════
// CASAS BAHIA — com stealth + URL corrigida
// O diagnóstico usava URL errada: /{keyword}/b (ativa WAF)
// URL correta: /busca/{keyword}
// Stealth scripts ajudam a evitar detecção do Akamai
// ═══════════════════════════════════════════════

async function scrapeCasasBahia(page, keyword, brands) {
  const url = buildSearchUrl('casasbahia', keyword);

  // Stealth já aplicado via applyStealthScripts no index.js
  await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 45000 });

  // Esperar bastante — CB é lenta e usa React hydration
  await page.waitForTimeout(8000);
  await aggressiveScroll(page);

  // Verificar se caímos na página de erro
  const isBlocked = await page.evaluate(() => {
    return document.title === '' ||
      !!document.querySelector('.page-not-found') ||
      document.body.textContent.includes('Algo deu errado');
  });

  if (isBlocked) {
    logWarn(`    Casas Bahia bloqueou acesso para "${keyword.term}" — tente novamente mais tarde`);
    return [];
  }

  const rawResults = await page.evaluate(() => {
    // CB usa classes dinâmicas (styled-components), então procuramos por padrões
    // Tentar múltiplas abordagens
    let cards = document.querySelectorAll('a[class*="ProductCard"]');
    if (cards.length === 0) cards = document.querySelectorAll('[class*="product-card"]');
    if (cards.length === 0) cards = document.querySelectorAll('a[href*="/produto/"]');
    if (cards.length === 0) {
      // Abordagem genérica: buscar links que contêm /p/ (padrão de produto CB)
      cards = document.querySelectorAll('a[href*="/p/"]');
    }

    const data = [];
    const seen = new Set(); // evitar duplicatas

    cards.forEach((item, index) => {
      if (data.length >= 20) return;
      try {
        // Título — h3 ou qualquer elemento com classe *title*
        let title = '';
        const h3 = item.querySelector('h3');
        if (h3) title = h3.textContent.trim();
        if (!title) {
          const titleEl = item.querySelector('[class*="title"], [class*="Title"]');
          if (titleEl) title = titleEl.textContent.trim();
        }
        if (!title || title.length < 10) return;
        if (seen.has(title)) return;
        seen.add(title);

        // Preço
        let price = null;
        const priceEl = item.querySelector('[class*="Price"], [class*="price"]');
        if (priceEl) {
          const m = priceEl.textContent.match(/[\d.]+,\d{2}/);
          if (m) price = parseFloat(m[0].replace(/\./g, '').replace(',', '.')) || null;
        }

        // Rating
        let rating = null;
        const ratingEl = item.querySelector('[class*="rating"], [class*="Rating"]');
        if (ratingEl) {
          const m = ratingEl.textContent.match(/[\d,]+/);
          if (m) rating = parseFloat(m[0].replace(',', '.'));
        }

        data.push({ title, price, rating, position: data.length + 1 });
      } catch (_) {}
    });
    return data;
  });

  if (rawResults.length === 0) {
    logWarn(`    Nenhum produto extraido em Casas Bahia para "${keyword.term}"`);
  } else {
    log(`    Extraidos ${rawResults.length} produtos via evaluate()`);
  }

  return rawResults.map(r => ({
    brand: detectBrand(r.title, brands), productName: r.title.substring(0, 150),
    organicPosition: r.position, sponsoredPosition: null, generalPosition: r.position,
    price: r.price, seller: '', fulfillment: 'Nao', rating: r.rating, reviewCount: null,
    tag: 'Nenhum', notes: '',
  }));
}

// ═══════════════════════════════════════════════
// SHOPEE — com cookies de login
// Requer rodar antes: node salvar-cookies.js shopee
// ═══════════════════════════════════════════════

async function scrapeShopee(context, page, keyword, brands) {
  // Verificar se tem cookies salvos
  if (!hasCookies('shopee')) {
    logWarn('    Shopee requer login. Rode primeiro: node salvar-cookies.js shopee');
    return [];
  }

  // Carregar cookies
  const loaded = await loadCookies(context, 'shopee');
  if (!loaded) {
    logWarn('    Falha ao carregar cookies do Shopee');
    return [];
  }
  log('    → Cookies do Shopee carregados');

  const url = buildSearchUrl('shopee', keyword);
  await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 45000 });
  await page.waitForTimeout(8000);

  // Verificar se fomos redirecionados para login
  const currentUrl = page.url();
  if (currentUrl.includes('/login') || currentUrl.includes('buyer/login')) {
    logWarn('    Cookies do Shopee expiraram. Rode: node salvar-cookies.js shopee');
    return [];
  }

  await aggressiveScroll(page);

  const rawResults = await page.evaluate(() => {
    // Shopee usa classes dinâmicas, buscar por estrutura
    let cards = document.querySelectorAll('.shopee-search-item-result__item');
    if (cards.length === 0) cards = document.querySelectorAll('[data-sqe="item"]');
    if (cards.length === 0) {
      // Fallback: cards dentro do grid de busca
      cards = document.querySelectorAll('.col-xs-2-4');
    }

    const data = [];
    cards.forEach((item, index) => {
      if (data.length >= 20) return;
      try {
        // Título — buscar o texto mais longo que parece nome de produto
        let title = '';
        const allText = item.querySelectorAll('div');
        for (const el of allText) {
          const t = el.textContent.trim();
          if (t.length > 20 && t.length < 200 && !t.includes('\n') && el.children.length <= 1) {
            title = t;
            break;
          }
        }
        if (!title || title.length < 10) return;

        // Preço — buscar elemento com R$ ou ₫
        let price = null;
        const priceEls = item.querySelectorAll('span');
        for (const el of priceEls) {
          const t = el.textContent.trim();
          if (t.match(/^R?\$?\s?[\d.]+,?\d*$/) && t.length < 15) {
            const cleaned = t.replace(/[R$\s]/g, '').replace(/\./g, '').replace(',', '.');
            price = parseFloat(cleaned) || null;
            if (price && price > 100) break; // preço realista para AC
          }
        }

        // Vendidos
        let sold = '';
        for (const el of allText) {
          const t = el.textContent.trim();
          if (t.match(/\d+\s*vendido/i)) { sold = t; break; }
        }

        data.push({ title, price, sold, position: data.length + 1 });
      } catch (_) {}
    });
    return data;
  });

  if (rawResults.length === 0) {
    logWarn(`    Nenhum produto extraido no Shopee para "${keyword.term}"`);
  } else {
    log(`    Extraidos ${rawResults.length} produtos via evaluate()`);
  }

  return rawResults.map(r => ({
    brand: detectBrand(r.title, brands), productName: r.title.substring(0, 150),
    organicPosition: r.position, sponsoredPosition: null, generalPosition: r.position,
    price: r.price, seller: '', fulfillment: 'Nao', rating: null, reviewCount: null,
    tag: r.sold || 'Nenhum', notes: '',
  }));
}

// ═══════════════════════════════════════════════
// GOOGLE SHOPPING — com stealth
// Pode falhar com reCAPTCHA — nesse caso retorna vazio
// ═══════════════════════════════════════════════

async function scrapeGoogleShopping(page, keyword, brands) {
  const url = buildSearchUrl('google_shopping', keyword);

  await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 30000 });
  await page.waitForTimeout(5000);

  // Verificar se caímos no captcha
  const isCaptcha = await page.evaluate(() => {
    return document.title.includes('sorry') ||
      !!document.querySelector('#captcha-form') ||
      !!document.querySelector('.g-recaptcha') ||
      document.body.textContent.includes('detectou tráfego incomum');
  });

  if (isCaptcha) {
    logWarn(`    Google Shopping bloqueou com CAPTCHA para "${keyword.term}"`);
    return [];
  }

  // Aceitar cookies Google
  try {
    const acceptBtn = await page.$('button:has-text("Aceitar tudo"), button:has-text("Accept all")');
    if (acceptBtn) await acceptBtn.click();
  } catch (_) {}

  await aggressiveScroll(page);

  const rawResults = await page.evaluate(() => {
    // Seletores Google Shopping
    let cards = document.querySelectorAll('.sh-dgr__gr-auto');
    if (cards.length === 0) cards = document.querySelectorAll('.sh-dlr__list-result');
    if (cards.length === 0) cards = document.querySelectorAll('[data-docid]');

    const data = [];
    cards.forEach((item, index) => {
      if (data.length >= 20) return;
      try {
        // Título
        let title = '';
        const h3 = item.querySelector('h3');
        if (h3) title = h3.textContent.trim();
        if (!title) {
          const nameEl = item.querySelector('.Xjkr3b, .tAxDx');
          if (nameEl) title = nameEl.textContent.trim();
        }
        if (!title || title.length < 5) return;

        // Preço
        let price = null;
        const priceEl = item.querySelector('.a8Pemb, .kHxwFf');
        if (priceEl) {
          const m = priceEl.textContent.match(/[\d.]+,\d{2}/);
          if (m) price = parseFloat(m[0].replace(/\./g, '').replace(',', '.')) || null;
        }

        // Vendedor
        let seller = '';
        const sellerEl = item.querySelector('.aULzUe, .IuHnof, .E5ocAb');
        if (sellerEl) seller = sellerEl.textContent.trim();

        // Rating
        let rating = null;
        const ratingEl = item.querySelector('.Rsc7Yb');
        if (ratingEl) {
          const m = ratingEl.textContent.match(/[\d,]+/);
          if (m) rating = parseFloat(m[0].replace(',', '.'));
        }

        data.push({ title, price, seller, rating, position: data.length + 1 });
      } catch (_) {}
    });
    return data;
  });

  if (rawResults.length === 0) {
    logWarn(`    Nenhum produto extraido no Google Shopping para "${keyword.term}"`);
  } else {
    log(`    Extraidos ${rawResults.length} produtos via evaluate()`);
  }

  return rawResults.map(r => ({
    brand: detectBrand(r.title, brands), productName: r.title.substring(0, 150),
    organicPosition: r.position, sponsoredPosition: null, generalPosition: r.position,
    price: r.price, seller: (r.seller || '').substring(0, 60), fulfillment: 'Nao',
    rating: r.rating, reviewCount: null, tag: 'Nenhum', notes: '',
  }));
}

// ═══════════════════════════════════════════════
// DISPATCHER + STEALTH SETUP
// ═══════════════════════════════════════════════

async function scrapeplatform(page, platform, keyword, brands, context) {
  switch (platform.id) {
    case 'meli':           return scrapeMeli(page, keyword, brands);
    case 'amazon':         return scrapeAmazon(page, keyword, brands);
    case 'magalu':         return scrapeMagalu(page, keyword, brands);
    case 'casasbahia':     return scrapeCasasBahia(page, keyword, brands);
    case 'shopee':         return scrapeShopee(context, page, keyword, brands);
    case 'google_shopping':return scrapeGoogleShopping(page, keyword, brands);
    default:
      logWarn(`  Scraper nao implementado para ${platform.id}`);
      return [];
  }
}

module.exports = { scrapeplatform, applyStealthScripts, detectBrand, buildSearchUrl };
