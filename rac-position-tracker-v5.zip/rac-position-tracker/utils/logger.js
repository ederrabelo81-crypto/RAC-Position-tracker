/**
 * Logger com cores e gravação em arquivo
 */
const fs = require('fs');
const path = require('path');

const COLORS = {
  reset: '\x1b[0m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  gray: '\x1b[90m',
};

const LOG_DIR = path.resolve('./logs');

function ensureLogDir() {
  if (!fs.existsSync(LOG_DIR)) fs.mkdirSync(LOG_DIR, { recursive: true });
}

function getLogFile() {
  ensureLogDir();
  const date = new Date().toISOString().split('T')[0];
  return path.join(LOG_DIR, `tracker_${date}.log`);
}

function writeToFile(msg) {
  const ts = new Date().toISOString();
  const clean = msg.replace(/\x1b\[\d+m/g, '');
  fs.appendFileSync(getLogFile(), `[${ts}] ${clean}\n`);
}

function log(msg) {
  console.log(`${COLORS.gray}${msg}${COLORS.reset}`);
  writeToFile(msg);
}

function logError(msg) {
  console.error(`${COLORS.red}${msg}${COLORS.reset}`);
  writeToFile(`ERROR: ${msg}`);
}

function logSuccess(msg) {
  console.log(`${COLORS.green}${msg}${COLORS.reset}`);
  writeToFile(`OK: ${msg}`);
}

function logWarn(msg) {
  console.log(`${COLORS.yellow}${msg}${COLORS.reset}`);
  writeToFile(`WARN: ${msg}`);
}

module.exports = { log, logError, logSuccess, logWarn };
