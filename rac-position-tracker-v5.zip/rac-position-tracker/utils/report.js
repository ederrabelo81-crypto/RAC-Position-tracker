/**
 * Gera relatório resumido no console ao final da coleta
 */
const { log, logSuccess, logWarn, logError } = require('./logger');

function generateReport(results, totalErrors, elapsedSeconds, turno) {
  log(`\n${'═'.repeat(60)}`);
  log('  RELATÓRIO DA COLETA');
  log(`${'═'.repeat(60)}`);

  // Resumo geral
  log(`  Turno: ${turno}`);
  log(`  Total de registros: ${results.length}`);
  log(`  Erros encontrados: ${totalErrors}`);
  log(`  Tempo de execução: ${elapsedSeconds}s`);

  if (results.length === 0) return;

  // Por plataforma
  const byPlatform = {};
  results.forEach(r => {
    if (!byPlatform[r.plataforma]) byPlatform[r.plataforma] = 0;
    byPlatform[r.plataforma]++;
  });
  log('\n  Por plataforma:');
  Object.entries(byPlatform).forEach(([plat, count]) => {
    log(`    ${plat}: ${count} registros`);
  });

  // Por marca
  const byBrand = {};
  results.forEach(r => {
    if (!byBrand[r.marca]) byBrand[r.marca] = { count: 0, positions: [] };
    byBrand[r.marca].count++;
    if (r.posicaoOrganica) byBrand[r.marca].positions.push(r.posicaoOrganica);
  });
  log('\n  Por marca (posição orgânica média):');
  Object.entries(byBrand)
    .sort((a, b) => a[1].positions.length > 0 && b[1].positions.length > 0
      ? (a[1].positions.reduce((s, v) => s + v, 0) / a[1].positions.length)
        - (b[1].positions.reduce((s, v) => s + v, 0) / b[1].positions.length)
      : 0)
    .forEach(([brand, data]) => {
      const avg = data.positions.length > 0
        ? (data.positions.reduce((s, v) => s + v, 0) / data.positions.length).toFixed(1)
        : 'N/A';
      log(`    ${brand}: ${data.count} aparições, pos. média: ${avg}`);
    });

  // Top 3 Midea
  const mideaResults = results.filter(r =>
    r.marca === 'Midea' || r.marca === 'Springer Midea' || r.marca === 'Carrier'
  );
  const mideaTop3 = mideaResults.filter(r => r.posicaoOrganica && r.posicaoOrganica <= 3);
  const mideaTop10 = mideaResults.filter(r => r.posicaoOrganica && r.posicaoOrganica <= 10);

  log('\n  Midea/Carrier/Springer:');
  logSuccess(`    Aparições Top 3: ${mideaTop3.length}`);
  logSuccess(`    Aparições Top 10: ${mideaTop10.length}`);
  log(`    Total aparições: ${mideaResults.length}`);

  // Alertas
  if (totalErrors > 5) {
    logError(`\n  ⚠ ALERTA: ${totalErrors} erros — verifique os seletores CSS`);
  }

  const sponsoredCompetitors = results.filter(r =>
    r.posicaoPatrocinada && !['Midea', 'Springer Midea', 'Carrier'].includes(r.marca)
  );
  if (sponsoredCompetitors.length > 0) {
    const competitorBrands = [...new Set(sponsoredCompetitors.map(r => r.marca))];
    logWarn(`\n  ⚠ Concorrentes com anúncios patrocinados: ${competitorBrands.join(', ')}`);
  }

  log(`\n${'═'.repeat(60)}\n`);
}

module.exports = { generateReport };
